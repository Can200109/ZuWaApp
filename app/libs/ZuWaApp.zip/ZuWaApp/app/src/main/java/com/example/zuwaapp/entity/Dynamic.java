package com.example.zuwaapp.entity;

/**
 * Created by WuLiang.
 * <p>
 * Date: 2021/11/27
 */
public class Dynamic {

}
